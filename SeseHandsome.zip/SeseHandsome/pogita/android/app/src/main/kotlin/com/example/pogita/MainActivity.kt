package com.example.pogita

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
